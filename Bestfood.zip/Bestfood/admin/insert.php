<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<?php
error_reporting(1);
include("connection.php");
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO item(img,prod_no,price)VALUES('$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("image/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"image/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err="<font size='+2'>item inserted successfully</font>";
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grand Restaurant</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo_justified.css" rel="stylesheet">
	<link href="style.css" rel="stylesheet" type="text/css" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div id="container" class="container">

        <a href="#"><img src="images/templatemo_header_blank2.jpg" alt="Simplex Responsive Template" class="img-responsive" /></a>
        
        <ul class="nav nav-justified">
          <li><a href="home.php">Home</a></li>
          <li class="active"><a href="insert.php">Insert</a></li>
          <li><a href="view-product.php">Product</a></li>
          <li><a href="view-order.php">Order</a></li>
          <li><a href="view-feedback.php">Feedback</a></li>
          <li><a href="logout.php">Log Out</a></li>
        </ul>

      	
      
            <br>
        <center>
			 <div id="contact_form" class="col_2">
                <h2>Insert Image</h2>
                
				<form  name="testform" method="post" enctype="multipart/form-data" >
			<table style="border-color:#eaea75;border-style: double;margin-center:0px;" width="600px" align="center">
				
						
				
				 <tr>
						<td height="20px"></td>
				</tr>	
				<tr>
				<td><span class="style3">Image:</span></td>
				<td>
					<input name="img" type="file" required placeholder>
				</td>
				</tr>
				 <tr>
						<td height="20px"></td>
				</tr>			
				
				<tr>
				  <td><span class="style3">product name: </span></td>
				  <td><label>
					<input name="t1" type="text" id="t1" required placeholder>
				  </label></td>
				</tr>
				 <tr>
						<td height="20px"></td>
				</tr>			
				
				<tr>
				  <td><span class="style3">Price:</span></td>
				  <td><label>
					<input name="t2" type="text" id="t2" required placeholder>
				  </label></td>
				</tr>
				 <tr>
						<td height="20px"></td>
				</tr>			
				
				
				
				
				<tr>
				<td  colspan="2" align="center">
					<input name="sub" type="submit" value="Submit">
					
				</td>
				</tr>
				
			</table>
			</form>
				<h2><?php echo $err;?></h2>
            </div> 
       
        </center>
        

        <div class="clear"></div>
   
	<div style="display:none;" class="nav_up" id="nav_up"></div>
            
       
            
            
     	
        
        
      

      <!-- Site footer -->
      <div class="footer">
        <p>Copyright © 2023 Grand Restaurant Co., Ltd.</p>
      </div>

    </div> <!-- /container -->
<?php }  ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>