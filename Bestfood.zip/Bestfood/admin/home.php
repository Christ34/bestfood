<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grand Restaurant</title>
    <meta name="description" content="">
    <meta name="author" content="templatemo">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo_justified.css" rel="stylesheet">
	<link href="style.css" rel="stylesheet" type="text/css" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div id="container" class="container">

        <a href="#"><img src="images/templatemo_header_blank2.jpg" alt="Simplex Responsive Template" class="img-responsive" /></a>
        
        <ul class="nav nav-justified">
          <li class="active"><a href="home.php">Home</a></li>
          <li><a href="insert.php">Insert</a></li>
          <li><a href="view-product.php">Product</a></li>
          <li><a href="view-order.php">Order</a></li>
          <li><a href="view-feedback.php">Feedback</a></li>
          <li><a href="logout.php">Log Out</a></li>
        </ul>
        
      <div class="row space30"> <!-- row 1 begins -->
      
            
        
            <marquee><h2><span>Hello ...Welcome  Admin</span></h2></marquee>
       
            <p>✓ Here you can customize it.</p>
			<p>✓ You can upload new products!</p>
			<p>✓ You can check orders!</p>
			<p>✓ Feedback can be read and accepted!</p>
        
      </div> <!-- /row 1 -->
      
      

      <!-- Site footer -->
      <div class="footer">
        <p>Copyright © 2023 Grand Restaurant Co., Ltd.</p>
      </div>

    </div> <!-- /container -->
<?php }  ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>