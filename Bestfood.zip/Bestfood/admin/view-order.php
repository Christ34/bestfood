<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grand Restaurant</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo_justified.css" rel="stylesheet">
	
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div id="container" class="container">

        <a href="#"><img src="images/templatemo_header_blank2.jpg" alt="Simplex Responsive Template" class="img-responsive" /></a>
        
        <ul class="nav nav-justified">
          <li><a href="home.php">Home</a></li>
          <li><a href="insert.php">Insert</a></li>
          <li><a href="view-product.php">Product</a></li>
          <li class="active"><a href="view-order.php">Order</a></li>
          <li><a href="view-feedback.php">Feedback</a></li>
          <li><a href="logout.php">Log Out</a></li>
        </ul>

      	<div class="row space30"> <!-- row 1 begins -->
      
      		<h2 align="center"> View Order form</h2>
       <table  style="border-color:#eaea75;border-style: double;margin-center:0px;" width="1000px" align="center" >
					
					<tr><th width="100px" height="50px">ID:</th>					
						<th width="100px" height="50px">Product NO:</th>
						<th width="100px" height="50px">Price:</th>
						<th width="100px" height="50px">Name:</th>
						<th width="100px" height="50px">Phone:</th>
						<th width="100px" height="50px">Address:</th>	
						<th width="100px" height="50px">Order No:</th>						
					 </tr>	
					 <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from orders ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['ord_id'];					
									$prodno=$row['productno'];
									$price=$row['price'];
									$name=$row['name'];
									$phone=$row['phone'];
									$address=$row['address'];
									$ordno=$row['order_no'];
						?>
					 <tr>
						
						<td width="100px" height="50px"><?php echo $id; ?></td>
						<td width="100px" height="50px"><?php echo $prodno; ?></td>
						<td width="100px" height="50px"><?php echo $price; ?></td>
						<td width="100px" height="50px"><?php echo $name; ?></td>
						<td width="100px" height="50px"><?php echo $phone; ?></td>
						<td width="100px" height="50px"><?php echo $address; ?></td>
						<td width="100px" height="50px"><?php echo $ordno; ?></td>
						
						
												
					  </tr>			
					<?php				  
							}	
					?>
					</table>
       
        
        

        <div class="clear"></div>
            
     	</div> <!-- /row 1 -->
        
        
      

      <!-- Site footer -->
      <div class="footer">
        <p>Copyright © 2023 Grand Restaurant Co., Ltd.</p>
      </div>

    </div> <!-- /container -->
<?php }  ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>