

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Grand Restaurant Products</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">
	 <!--link rel="stylesheet" href="tooplate_style.css"-->

  </head>
<body>

<!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

	<!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Best <em>Food</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="products.php">Our Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact Us</a>
              </li>
			  <li class="nav-item active">
                <a class="nav-link" href="register.php">Register</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
	
	<!-- Page Content -->
    <div class="page-heading registration-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>Registration Now</h4>
              <h2>Get in touch</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
	<br><br>
    <div id="tooplate_main">
    	<div id="" class="col-md-8">
          <div class="contact_form">
            
              <h2>Register form</h2>
            <br><br>
            <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$phone=$_POST['t4'];
$city=$_POST['t5'];
$town=$_POST['t6'];
if(mysql_query("insert into register(name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')"))
{
//echo "<script>location.href='reg_success.php?email=$email'</script>"; 
header("location:reg_success.php?name=$name & email=$email");}
else {$error= "user already exists";}}

?>
            <form  method="post">
                <label>Name </label>
                <input type="text" placeholder="Full Name" required="" name="t1" id="t1" class="form-control" />
                <label>Email</label>
                <input type="email" placeholder="E-mail Address" required="" name="t2" id="t2" class="form-control" />
				 <label>Password</label>
                <input type="password" placeholder="Password" required="" name="t3" id="t3" class="form-control" />
				 <label>Phone </label>
                <input type="text" placeholder="Your Phone Number" required="" name="t4" id="t4" class="form-control" />
				 <label>City </label>
                <input type="text" placeholder="Your City" required="" name="t5" id="t5" class="form-control" />
				 <label>Country </label>
                <input type="text" placeholder="Your Country" required="" name="t6" id="t6" class="form-control" /><br>
                <input type="submit" name="sub" id="sub" value="Register" class="submit_button" />
				 <input type="reset" name="Cancel" value="Cancel" class="submit_button" />
				<label><?php echo "<font color='red'>$error</font>";?></label>
            </form>
            
        
        </div>  
            
            
            
            
            
            
        </div> <!-- END of content -->
                
		
            
           
      </div>
        
        <div class="clear"></div>
		

    <div style="display:none;" class="nav_up" id="nav_up"></div>

<footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2023 Grand Restaurant Co., Ltd.
            
            - Design: Zin Bo Han</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
	
<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>
	
<script src="js/scroll-startstop.events.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		var $elem = $('#content');
		
		$('#nav_up').fadeIn('slow');
		
		$(window).bind('scrollstart', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'0.2'});
		});
		$(window).bind('scrollstop', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'1'});
		});
		
		$('#nav_up').click(
			function (e) {
				$('html, body').animate({scrollTop: '0px'}, 800);
			}
		);
	});
</script>

</body>
</html>